use strum::{EnumCount, VariantArray};

pub mod blit_geometry;
pub mod bounded_cache;
mod commands;
pub mod crumb;
pub mod fatal;
pub mod ffi_boundary;
pub mod ftol;
pub mod identity;
mod log_filter;
mod log_helpers;
pub mod log_paths;
pub mod mtl;
pub mod mtl_handle;
mod params;
pub mod perf;
pub mod record_handle;
pub mod texture_views;
pub mod trig;
pub mod tsc;

pub use commands::{
    BlitCommand, BlitCommandType, Command, CommandType, CopyBufferToBufferInfo,
    CopyBufferToTextureInfo, CopyTextureSubRectInfo, NullTextureKind,
};
pub use ffi_boundary::{InPtr, InPtrMut, OutPtr, ValueIn, VtableThis, slice_from_caller};
pub use log_filter::{init_logger, init_logger_to};
pub use mtl_handle::MetalHandle;
pub use params::{
    AttachMetalLayerParams, BlitTextureToBufferParams, BufferCreateDesc,
    CompileShaderLibraryParams, CreateBackbufferParams, CreateBuffersBatchParams,
    CreateColorTargetParams, CreateCommandQueueParams, CreateDepthStencilStateParams,
    CreateDepthTextureParams, CreateDepthTransferPipelineParams, CreateRenderPipelineParams,
    CreateSamplerStateParams, CreateTextureSliceViewParams, CreateTexturesBatchParams,
    DestroyCommandQueueParams, DestroyResourcesBulkParams, DetachMetalLayerParams,
    EnsureBlitPipelineParams, EnsureClearQuadPipelineParams, ExtraColorAttachmentParams,
    ExtraColorDesc, GetDeviceInfoParams, GetTaskFaultsParams, InitLoggerParams, OpenLogParams,
    PassDescriptor, SetCursorOverlayParams, SetDisplaySyncEnabledParams, SetGammaRampParams,
    SetPresentWaitPolicyParams, StartGpuCaptureParams, StencilFaceParams, StopGpuCaptureParams,
    SubmitFrameParams, TextureCreateDesc, VertexAttrDesc, VertexBufferLayoutDesc,
    WaitForGpuRetireParams, WaitForPresentIdleParams, WriteLogParams,
};
pub use record_handle::DeviceRecordHandle;

#[repr(u32)]
#[derive(Clone, Copy, EnumCount, VariantArray)]
pub enum Thunks {
    InitLogger,
    GetDeviceInfo,
    CreateCommandQueue,
    AttachMetalLayer,
    DestroyCommandQueue,
    CreateBackbuffer,
    CreateRenderPipeline,
    SubmitFrame,
    CreateDepthTexture,
    CreateColorTarget,
    CreateDepthStencilState,
    CreateTexturesBatch,
    CreateSamplerState,
    CompileShaderLibrary,
    CreateBuffersBatch,
    BlitTextureToBuffer,
    SetDisplaySyncEnabled,
    DestroyResourcesBulk,
    WaitForGpuRetire,
    StartGpuCapture,
    StopGpuCapture,
    EnsureClearQuadPipeline,
    EnsureBlitPipeline,
    CreateTextureSliceView,
    GetTaskFaults,
    WriteLog,
    OpenLog,
    SetCursorOverlay,
    DetachMetalLayer,
    SetPresentWaitPolicy,
    WaitForPresentIdle,
    CreateDepthTransferPipeline,
    SetGammaRamp,
}

pub trait Thunk {
    const CODE: u32;
}
