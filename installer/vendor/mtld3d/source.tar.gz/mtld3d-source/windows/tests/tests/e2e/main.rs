//! The end-to-end suite, one test binary so one Wine process runs it all.
//!
//! Every module here drives the real `d3d9.dll` through the shared
//! [`mtld3d_tests::Harness`], and the tests of all of them run on the
//! threads of this one process, each with its own device. The three files
//! that stay outside are the ones that need a process of their own:
//! `exit_code.rs` ends the process it runs in, `unload.rs` frees the
//! library, so nothing else may keep it mapped, and `snmalloc_drift.rs`
//! installs its own global allocator. `COVERAGE.md` indexes the modules;
//! this file only declares them.

mod a2b10g10r10;
mod a2r10g10b10;
mod buffers;
mod clip_planes;
mod d3d9ex;
mod d3dperf;
mod device;
mod draw;
mod dxt_volume;
mod dynamic_depth;
mod expand16;
mod float_filter;
mod format_query;
mod implicit_surface;
mod mrt;
mod msaa;
mod multi_device;
mod multithreaded;
mod no_color_passes;
mod non_uma;
mod one_off_passes;
mod packed10;
mod points;
mod present_split;
mod query;
mod range_fog;
mod render_scale;
mod render_states;
mod render_target;
mod resource_misc;
mod samplers;
mod sampling_views;
mod shaders;
mod smoke;
mod state_block;
mod streams;
mod subresource_identity;
mod table_fog;
mod texture_stages;
mod textures;
mod transforms_ff;
mod vertex_decl;
mod wide_stretch;
mod window_lifecycle;
mod wireframe;
